
import { Component, OnInit } from '@angular/core';
import { MyDataService } from './../../my-data.service';
import { FormControl, FormGroup, Validators,NgForm } from '@angular/forms';

import { HttpClient } from '@angular/common/http';
import { Http,Headers,Response, RequestOptions } from '@angular/http';
import { HttpErrorResponse } from '@angular/common/http';
import 'rxjs/add/operator/map'
import { userpetdetail } from './../../models/userpetdetail';
import {ActivatedRoute} from '@angular/router';

import {MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import {MatDatepicker} from '@angular/material/datepicker';

import {IMyDpOptions} from 'mydatepicker';


@Component({
  templateUrl: './user-pet-detail.component.html',
  styleUrls: ['./user-pet-detail.component.css'],

})
export class UserPetDetailComponent{
public myDatePickerOptions: IMyDpOptions = {
    // other options...
    dateFormat: 'dd.mm.yyyy',
};
public myDatePicker: IMyDpOptions = {
  // other options...
  dateFormat: 'mm.yyyy',
};
public myDate: IMyDpOptions = {
  // other options...
  dateFormat: 'dd.mm.yyyy',
};
public my: IMyDpOptions = {
  // other options...
  dateFormat: 'dd.mm.yyyy',
};
// Initialized to specific date (09.10.2018).
// public model: any = { date: { year: 2018, month: 10, day: 9 } };
// public model1: any = { date: { year: 2018, month: 10 } };
 //---------------------------------------------------------------------------

public model: any;
public model1: any;
public model2: any;
public model3: any ;

  

  viewuser: any = {}
  user_id:string;
  pet_id:string;
  public activity_data:any = {}
  public dailyData: any = {}
  public petdetail: any = {}
  private image:String="";
  public foodcompany: any = {}
  public submited:any;
  breeds: any = {}
  public ub:any;
  public userview:object = {};
  petlist: any
  // public lineChartData;
  // public lineChartLabels;
  // public lineChartType;
  // public lineChartColors;
  date;
  date1;
  public lineChartData:Array<any> = [
    [65, 59, 80, 81, 56, 55, 40],
    [28, 48, 40, 19, 86, 27, 90]
  ];
  public lineChartLabels:Array<any> = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
  public lineChartType:string = 'line';
  public lineChartColors = [
        { // grey
          backgroundColor: 'transparent',
          borderColor: 'rgba(148,159,177,1)',
          pointBackgroundColor: 'rgba(148,159,177,1)',
          pointBorderColor: '#fff',
          pointHoverBackgroundColor: '#fff',
          pointHoverBorderColor: 'rgba(148,159,177,0.8)'
        }
      ]
    
  isValidFormSubmitted = null;
  public _Array3: userpetdetail;
  userForm = new FormGroup
 ({
    pet_id:new FormControl(""),
    owner_name: new FormControl(""),
    age: new FormControl(""),
    owner_email: new FormControl(""),
 });
 


constructor(private apiSerivce: MyDataService, route: ActivatedRoute) 
{
  this.user_id = route.snapshot.params['user_id'];
  this.pet_id = route.snapshot.params['pet_id'];
  console.log(this.user_id);
  console.log(this.pet_id);
}


ngOnInit(): void 
  {
    
    this.date= new Date()
    this.date1 = new Date()
    console.log(this.date)
    this.apiSerivce.edituserpetdetail({'user_id':this.user_id,'pet_id':this.pet_id})
    .subscribe( resultArray =>{console.log(resultArray)
    this.userview = resultArray.petdetail;
    console.log(this.userview);
  });
  this.graphdetail(); 
   
}

  public updatebreed(userForm: NgForm){
    this.ub.updatefoodcompany(userForm.value);
  }
  public edituserview(){
    this.apiSerivce.edituserpetdetail({'user_id': this.user_id,'pet_id':this.pet_id}).subscribe( resultArray =>{console.log(resultArray)
    this.userview = resultArray.petdetail ;
    console.log(this.userview);
   })
  }
  onSubmit()
  {
    const headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });
    this.userForm.value.user_id = this.user_id;
    this.submited = true;
  }
  graph(){
    let lineChartData =   [65, 59, 80, 81, 56, 55, 40];
    lineChartData.forEach(function (value){
       console.log(value);
    }
    );
    let lineChartLabels =  ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
    lineChartLabels.forEach(function (value){
      console.log(value);})
    this.lineChartData = [
        [65, 59, 80, 81, 56, 55, 40]
      ];
    this.lineChartLabels = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
    this.lineChartType = 'line';
    this.lineChartColors = [
        { // grey
          backgroundColor: 'transparent',
          borderColor: 'rgba(148,159,177,1)',
          pointBackgroundColor: 'rgba(148,159,177,1)',
          pointBorderColor: '#fff',
          pointHoverBackgroundColor: '#fff',
          pointHoverBorderColor: 'rgba(148,159,177,0.8)'
        }
      ]
  }
  public chartClicked(e:any):void {
    console.log(e);
  }
  
  public chartHovered(e:any):void {
    console.log(e);
  }
 
  
 
  graphdetail(){
    // alert("1")
    /* Date Format */
    var dt = this.date,              
    month = '' + (dt.getMonth()+1),             
     day = '' + dt.getDate(),              
     year = dt.getFullYear();              
     if (month.length < 2) month = '0' + month;             
      if (day.length < 2) day = '0' + day;             
       var k = [year, month, day].join('-');             
        this.date = k;
        console.log(this.date )

        
    this.apiSerivce.graphdetail({'user_id':this.user_id,'pet_id':this.pet_id,'activity_date': this.date,'current_time': this.date1,'graph_status': '1'})
    .subscribe( resultArray =>{
     this.userview = resultArray;
      this.graph();
      // this.userview.adoption_date = new Date(this.userview.adoption_date);
      // this.userview.score_date = new Date(this.userview.score_date);
      // console.log(new Date(this.userview.adoption_date))
       console.log(this.userview);
       //-------------------------------------------------------
       
 


    })
  }
  // weekData(){
  //   this.apiSerivce.graphdetail({'user_id':this.user_id,'pet_id':this.pet_id,'activity_date': this.date,'week_start':this.date,'week_end':this.date,'current_time': this.date1,'graph_status':'2'}).subscribe( resultArray =>{console.log(resultArray)
  //     this.userview = resultArray;
  //       console.log(this.userview);
  //   });
  // }

  
}
/* -- Date Conversion --*/              

